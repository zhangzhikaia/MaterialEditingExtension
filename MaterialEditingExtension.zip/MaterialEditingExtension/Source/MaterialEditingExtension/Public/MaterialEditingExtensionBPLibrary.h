// Copyright lurongjiu. All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "MaterialEditingExtensionBPLibrary.generated.h"


UENUM()
enum EMaterialPropertySeek : int
{
	MPS_WorldPositionOffset UMETA(DisplayName = "WorldPositionOffset"),
	MPS_PixelDepthOffset UMETA(DisplayName = "PixelDepthOffset"),
	MPS_MaterialAttributes UMETA(DisplayName = "MaterialAttributes"),
};

enum EMaterialDomain : int;
enum EBlendMode : int;
enum EMaterialShadingModel : int;
class UMaterialExpressionCustom;

UCLASS()
class UMaterialEditingExtensionBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Execute Sample function", Keywords = "MaterialEditingExtension sample test testing"), Category = "MaterialEditingExtensionTesting")
	static float MaterialEditingExtensionSampleFunction(float Param);


	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "MaterialEditingExtension")
	static bool GetMaterialUseAttribute(const UMaterial* Material);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialUseAttribute(UMaterial* Material,bool UseAttribute);

	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "MaterialEditingExtension")
	static bool GetMaterialTwoSided(const UMaterial* Material);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialTwoSided(UMaterial* Material, bool TwoSided);

	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "MaterialEditingExtension")
	static bool GetMaterialCastRayTracedShadows(const UMaterial* Material);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialCastRayTracedShadows(UMaterial* Material, bool CastRayTracedShadows);

	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static bool ConnectMaterialPropertyPlus(UMaterialExpression* FromExpression, FString FromOutputName, EMaterialPropertySeek MaterialPropertySeek);

	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialDomain(UMaterial* Material, EMaterialDomain MaterialDomainSet);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialBlendMode(UMaterial* Material, EBlendMode MaterialBlendModeSet);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetMaterialShadingModel(UMaterial* Material, EMaterialShadingModel MaterialShadingModelSet);

	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "MaterialEditingExtension")
	static UMaterialExpressionCustom* GetCustomByDescription(UMaterial* Material, FString DescriptionCheck);
	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "MaterialEditingExtension")
	static FString GetCustomCode(UMaterialExpressionCustom* ExpressionCustom);
	UFUNCTION(BlueprintCallable, Category = "MaterialEditingExtension")
	static void SetCustomCode(UMaterialExpressionCustom* ExpressionCustom, FString CodeSet);

};
